package org.thoughtcrime.securesms;

public class TextSecureExpiredException extends Exception {
  public TextSecureExpiredException(String message) {
    super(message);
  }
}
